import React from 'react';
import { X, CheckCircle, Download, Printer, ShieldCheck, Landmark } from 'lucide-react';
import { Transaction } from '../types/bank';
import { BANK_CONFIG } from '../config/bankConfig';
import { useBank } from '../context/BankContext';

interface TransactionReceiptModalProps {
  transaction: Transaction | null;
  onClose: () => void;
}

export const TransactionReceiptModal: React.FC<TransactionReceiptModalProps> = ({
  transaction,
  onClose,
}) => {
  const { formatAmount } = useBank();

  if (!transaction) return null;

  const handlePrint = () => {
    window.print();
  };

  const isDebit = transaction.amount < 0;
  const absAmount = Math.abs(transaction.amount);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950/50 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Landmark className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">
                Official Wire Transfer Receipt
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Ref: {transaction.referenceNumber}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Receipt Printable Card */}
        <div className="p-6 space-y-5 text-slate-200 overflow-y-auto max-h-[75vh]">
          {/* Status Badge */}
          <div className="flex flex-col items-center justify-center text-center p-4 bg-emerald-950/30 border border-emerald-500/30 rounded-2xl space-y-1">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 mb-1">
              <CheckCircle className="w-6 h-6" />
            </div>
            <span className="text-xs uppercase tracking-wider font-semibold text-emerald-400">
              Transaction Completed & Settled
            </span>
            <div className="text-2xl sm:text-3xl font-bold font-mono text-white">
              {isDebit ? '-' : '+'}{formatAmount(absAmount)}
            </div>
            <p className="text-xs text-slate-400">{transaction.description}</p>
          </div>

          {/* Details Table */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-3 text-xs">
            <div className="flex justify-between border-b border-slate-800/80 pb-2">
              <span className="text-slate-400">Originating Bank</span>
              <span className="font-semibold text-white">{BANK_CONFIG.bankName}</span>
            </div>
            <div className="flex justify-between border-b border-slate-800/80 pb-2">
              <span className="text-slate-400">Date & Timestamp</span>
              <span className="text-slate-200">{transaction.date}</span>
            </div>
            {transaction.recipientName && (
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Beneficiary Name</span>
                <span className="font-semibold text-emerald-400">{transaction.recipientName}</span>
              </div>
            )}
            {transaction.recipientBank && (
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Beneficiary Bank</span>
                <span className="text-slate-200">{transaction.recipientBank}</span>
              </div>
            )}
            {transaction.recipientAccount && (
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Beneficiary Account #</span>
                <span className="font-mono text-slate-200">
                  •••• {transaction.recipientAccount.slice(-4)} ({transaction.recipientAccount})
                </span>
              </div>
            )}
            <div className="flex justify-between border-b border-slate-800/80 pb-2">
              <span className="text-slate-400">Transaction Category</span>
              <span className="text-slate-200">{transaction.category}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Wire Settlement Speed</span>
              <span className="text-emerald-400 font-medium">Real-Time Gross Settlement (RTGS)</span>
            </div>
          </div>

          {/* Security stamp */}
          <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700/60 flex items-center gap-3 text-[11px] text-slate-400">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <span className="text-slate-200 font-medium">Transaction Record</span>
              <p>Nortval Digital Signature Cryptographically Signed & Logged on Ledger.</p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              onClick={handlePrint}
              className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium py-2.5 px-4 rounded-xl text-xs border border-slate-700 transition-colors"
            >
              <Printer className="w-4 h-4 text-slate-400" />
              <span>Print Receipt</span>
            </button>
            <button
              onClick={onClose}
              className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2.5 px-4 rounded-xl text-xs transition-colors shadow-lg shadow-emerald-950"
            >
              <Download className="w-4 h-4" />
              <span>Close / Done</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
