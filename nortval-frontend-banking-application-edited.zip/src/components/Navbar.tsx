import React, { useState } from 'react';
import { Landmark, Phone, LogOut, Menu, X, Sparkles } from 'lucide-react';
import { useBank } from '../context/BankContext';
import { BANK_CONFIG } from '../config/bankConfig';

interface NavbarProps {
  onOpenTransferModal: () => void;
  onNavigate: (tab: string) => void;
  activeTab: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenTransferModal, onNavigate, activeTab }) => {
  const { user, logout, openCustomerService, openLoanModal } = useBank();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigate = (tab: string) => {
    onNavigate(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-30 bg-slate-900/95 border-b border-slate-800/80 backdrop-blur-md text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          <button type="button" className="flex items-center gap-3 text-left" onClick={() => navigate('dashboard')}>
            <div className="relative flex items-center justify-center w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-emerald-500/20 via-slate-800 to-slate-900 border border-emerald-500/40 text-emerald-400 shadow-md">
              <Landmark className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg sm:text-xl font-bold tracking-tight text-white font-serif">NORTVAL</span>
                <span className="text-[10px] font-semibold uppercase tracking-widest text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">Private Bank</span>
              </div>
              <p className="text-[10px] text-slate-400 tracking-wider">EST. {BANK_CONFIG.establishedYear}</p>
            </div>
          </button>

          <nav className="hidden md:flex items-center gap-1 text-xs font-medium">
            {[
              ['dashboard', 'Accounts'],
              ['transactions', 'Transactions'],
              ['cards', 'Cards'],
              ['settings', 'Profile & Settings'],
            ].map(([tab, label]) => (
              <button key={tab} onClick={() => navigate(tab)} className={`px-3 py-2 rounded-lg transition-colors ${activeTab === tab ? 'bg-slate-800 text-emerald-400 font-semibold' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'}`}>
                {label}
              </button>
            ))}
            <button onClick={openLoanModal} className="px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors">Loans</button>
          </nav>

          <div className="hidden lg:flex items-center gap-2.5">
            <button onClick={onOpenTransferModal} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md shadow-emerald-950 transition-all">
              <Sparkles className="w-3.5 h-3.5" /> Transfer & Wire
            </button>
            <button onClick={() => openCustomerService('Header Concierge Request')} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold hover:bg-slate-700 transition-colors">
              <Phone className="w-3.5 h-3.5 text-emerald-400" /> SMS Support
            </button>
            <button onClick={() => navigate('settings')} className="flex items-center gap-2 pl-2 pr-3 py-1 rounded-xl bg-slate-800/80 border border-slate-700/80 text-xs text-slate-200">
              <img src={user.avatarUrl} alt={user.name} className="w-6 h-6 rounded-full object-cover border border-emerald-500/40" />
              <span className="font-medium truncate max-w-[100px]">{user.name.split(' ')[0]}</span>
            </button>
            <button onClick={logout} title="Sign Out" className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors"><LogOut className="w-4 h-4" /></button>
          </div>

          <div className="flex items-center gap-2 lg:hidden">
            <button onClick={() => openCustomerService()} className="p-2 rounded-lg bg-emerald-600 text-white text-xs flex items-center justify-center" aria-label="SMS Support"><Phone className="w-4 h-4" /></button>
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="p-2 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800" aria-label="Toggle menu">{mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}</button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-800 py-3 space-y-2 text-xs">
            <div className="flex items-center gap-2 px-2 pb-2 border-b border-slate-800">
              <img src={user.avatarUrl} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
              <div className="font-semibold text-white">{user.name}</div>
            </div>
            <div className="grid grid-cols-2 gap-1 pt-1">
              <button onClick={() => navigate('dashboard')} className="p-2 text-left rounded-lg hover:bg-slate-800 text-slate-200">Accounts Overview</button>
              <button onClick={() => { onOpenTransferModal(); setMobileMenuOpen(false); }} className="p-2 text-left rounded-lg hover:bg-slate-800 text-emerald-400 font-semibold">Transfer & Wire</button>
              <button onClick={() => navigate('transactions')} className="p-2 text-left rounded-lg hover:bg-slate-800 text-slate-200">Transactions</button>
              <button onClick={() => navigate('cards')} className="p-2 text-left rounded-lg hover:bg-slate-800 text-slate-200">Debit Cards</button>
              <button onClick={() => { openLoanModal(); setMobileMenuOpen(false); }} className="p-2 text-left rounded-lg hover:bg-slate-800 text-slate-200">Loans & Credit</button>
              <button onClick={() => navigate('settings')} className="p-2 text-left rounded-lg hover:bg-slate-800 text-slate-200">Profile Picture</button>
            </div>
            <div className="pt-2 border-t border-slate-800 flex justify-between px-2">
              <button onClick={() => { openCustomerService(); setMobileMenuOpen(false); }} className="text-emerald-400 hover:underline">SMS Support: {BANK_CONFIG.customerServicePhone}</button>
              <button onClick={logout} className="text-red-400 hover:underline flex items-center gap-1"><LogOut className="w-3.5 h-3.5" /> Sign Out</button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
