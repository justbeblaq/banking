export interface UserProfile {
  username: string;
  name: string;
  avatarUrl: string;
  phone: string;
}

export type TransactionType = 'transfer_out' | 'transfer_in' | 'deposit' | 'bill_pay' | 'fee' | 'interest';
export type TransactionStatus = 'completed' | 'pending' | 'flagged' | 'reversed';

export interface Transaction {
  id: string;
  referenceNumber: string;
  date: string;
  timestamp: number;
  type: TransactionType;
  description: string;
  recipientName?: string;
  recipientBank?: string;
  recipientAccount?: string;
  amount: number;
  currency: string;
  status: TransactionStatus;
  category: 'Wire Transfer' | 'ACH Transfer' | 'Direct Deposit' | 'Account Funding' | 'Service Fee';
  note?: string;
}

export interface BankCard {
  id: string;
  cardNumber: string;
  cardHolder: string;
  expiryDate: string;
  cvv: string;
  type: 'Visa Infinite Debit' | 'Mastercard World Elite';
  isFrozen: boolean;
  spendingLimit: number;
  dailyWithdrawalLimit: number;
  color: string;
}

export interface TransferPayload {
  recipientName: string;
  recipientBank: string;
  recipientAccount: string;
  routingNumber?: string;
  amount: number;
  transferType: 'wire' | 'ach' | 'instant';
  note?: string;
}

export interface SupportTicket {
  id: string;
  subject: string;
  message: string;
  date: string;
  status: 'Open' | 'In Progress' | 'Escalated to SMS Agent';
  category: string;
}
