import React, { useState } from 'react';
import { 
  Landmark, ShieldCheck, Lock, User, KeyRound, Eye, EyeOff,
  ArrowRight, AlertTriangle, Phone,
  Shield
} from 'lucide-react';
import { useBank } from '../context/BankContext';
import { BANK_CONFIG } from '../config/bankConfig';

export const LoginPage: React.FC = () => {
  const { login, openCustomerService } = useBank();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [pin, setPin] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showPin, setShowPin] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [errorType, setErrorType] = useState<'WRONG_USERNAME' | 'WRONG_PASSWORD' | 'WRONG_PIN' | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setErrorType(null);
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      const res = login(username, password, pin);
      if (!res.success) {
        setErrorMessage(res.message || 'Authentication failed.');
        setErrorType(res.errorType || null);
      }
    }, 600);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between relative overflow-hidden font-sans">
      {/* Background Decorative Gradients */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none"></div>

      {/* Top Header */}
      <header className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between z-10 border-b border-slate-900/80">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 via-slate-800 to-slate-900 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shadow-lg">
            <Landmark className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold tracking-tight text-white font-serif">
                NORTVAL
              </span>
              <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/20">
                Secure Client Portal
              </span>
            </div>
            <p className="text-[10px] text-slate-400">
              Private Wealth & Commercial Trust
            </p>
          </div>
        </div>

        {/* Support Access from outside */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => openCustomerService('Login Assistance Request')}
            className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-emerald-400 hover:text-emerald-300 px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all shadow-sm"
          >
            <Phone className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">24/7 SMS Support:</span>
            <span className="font-mono font-bold text-white">{BANK_CONFIG.customerServicePhone}</span>
          </button>
        </div>
      </header>

      {/* Main Login Container */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6 z-10">
        <div className="w-full max-w-md bg-slate-900/90 border border-slate-800/90 rounded-2xl shadow-2xl p-6 sm:p-8 backdrop-blur-xl relative">
          {/* Header Inside Card */}
          <div className="text-center space-y-1.5 mb-6">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mb-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>256-Bit SSL Encrypted Session</span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight font-serif">
              Sign In to Nortval
            </h2>
            <p className="text-xs text-slate-400">
              Enter your authorized credentials and 4-digit security PIN.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Username */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Client Username
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="harriet020"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className={`w-full bg-slate-950 border rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 transition-all font-medium ${
                    errorType === 'WRONG_USERNAME'
                      ? 'border-red-500/80 focus:border-red-500 focus:ring-red-500/40'
                      : 'border-slate-700 focus:border-emerald-500 focus:ring-emerald-500'
                  }`}
                />
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
              </div>
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-slate-300">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => openCustomerService('Password Recovery', `I forgot my password for username ${username}.`)}
                  className="text-[11px] text-emerald-400 hover:text-emerald-300 transition-colors"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="••••••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`w-full bg-slate-950 border rounded-xl pl-10 pr-10 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 transition-all ${
                    errorType === 'WRONG_PASSWORD'
                      ? 'border-red-500/80 focus:border-red-500 focus:ring-red-500/40'
                      : 'border-slate-700 focus:border-emerald-500 focus:ring-emerald-500'
                  }`}
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-1 text-slate-400 hover:text-slate-200 absolute right-3 top-2.5"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Security PIN */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-emerald-400" />
                  <span>4-Digit Authorization PIN</span>
                </label>
                <span className="text-[11px] text-slate-500">2-Factor Auth Code</span>
              </div>
              <div className="relative">
                <input
                  type={showPin ? 'text' : 'password'}
                  maxLength={4}
                  required
                  placeholder="0921"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  className={`w-full bg-slate-950 border rounded-xl pl-10 pr-10 py-2.5 text-sm font-mono tracking-widest text-white placeholder-slate-500 focus:outline-none focus:ring-1 transition-all ${
                    errorType === 'WRONG_PIN'
                      ? 'border-red-500/80 focus:border-red-500 focus:ring-red-500/40'
                      : 'border-slate-700 focus:border-emerald-500 focus:ring-emerald-500'
                  }`}
                />
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="p-1 text-slate-400 hover:text-slate-200 absolute right-3 top-2.5"
                >
                  {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error Message Diagnostics Banner with Direct Customer Service Link */}
            {errorMessage && (
              <div className="p-4 bg-red-950/40 border border-red-500/50 rounded-xl space-y-2.5 text-red-200 animate-in fade-in duration-200">
                <div className="flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <div className="space-y-1 text-xs">
                    <p className="font-semibold text-red-300">
                      {errorType === 'WRONG_USERNAME' && 'Account Does Not Exist'}
                      {errorType === 'WRONG_PASSWORD' && 'Incorrect Password'}
                      {errorType === 'WRONG_PIN' && 'Invalid Security PIN'}
                      {!errorType && 'Authentication Notice'}
                    </p>
                    <p className="text-slate-300 leading-relaxed text-[11px]">
                      {errorMessage}
                    </p>
                  </div>
                </div>

                {/* Redirect to Customer Service Action */}
                <div className="pt-2 border-t border-red-800/40 flex items-center justify-between">
                  <span className="text-[11px] text-red-300">Requires recovery?</span>
                  <button
                    type="button"
                    onClick={() => openCustomerService('Login Credentials Recovery', `Login failed (${errorType}): ${errorMessage}`)}
                    className="inline-flex items-center gap-1.5 bg-red-600 hover:bg-red-500 text-white font-semibold text-xs px-3 py-1.5 rounded-lg shadow-md transition-colors"
                  >
                    <span>Contact Customer Service</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-semibold py-3 px-4 rounded-xl text-xs transition-all shadow-lg shadow-emerald-950/80 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 mt-2"
            >
              {isLoading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                  <span>Verifying Client Credentials...</span>
                </>
              ) : (
                <>
                  <span>Sign In to Nortval Account</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

        </div>
      </main>

      {/* Footer */}
      <footer className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 border-t border-slate-900/80 gap-2 z-10">
        <div className="flex items-center gap-2">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span>© {new Date().getFullYear()} Nortval Bank & Trust. All Rights Reserved.</span>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          <button
            onClick={() => openCustomerService('Footer Inquiries')}
            className="text-emerald-400 hover:underline"
          >
            SMS Support ({BANK_CONFIG.customerServicePhone})
          </button>
        </div>
      </footer>
    </div>
  );
};
