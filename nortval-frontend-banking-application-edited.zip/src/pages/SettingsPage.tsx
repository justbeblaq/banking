import React, { useState } from 'react';
import { Image, Check } from 'lucide-react';
import { useBank } from '../context/BankContext';

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80',
];

export const SettingsPage: React.FC = () => {
  const { user, updateProfile } = useBank();
  const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl);
  const [customAvatarInput, setCustomAvatarInput] = useState('');
  const [saved, setSaved] = useState(false);

  const saveAvatar = (value: string) => {
    setAvatarUrl(value);
    updateProfile({ avatarUrl: value });
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-2xl">
        <h1 className="text-xl sm:text-2xl font-bold text-white font-serif">Profile Picture</h1>
        <p className="text-xs text-slate-400 mt-1">Choose the picture displayed on your profile.</p>
      </div>

      <section className="max-w-3xl bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
        <div className="flex items-center gap-4">
          <img src={avatarUrl} alt="Profile" className="w-20 h-20 rounded-2xl object-cover border-2 border-emerald-500/40" />
          <div>
            <div className="text-sm font-semibold text-white">{user.name}</div>
            <div className="text-xs text-slate-400">Profile photo</div>
          </div>
        </div>

        <div>
          <div className="flex items-center gap-2 mb-3">
            <Image className="w-4 h-4 text-emerald-400" />
            <h2 className="text-sm font-bold text-white">Choose a picture</h2>
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
            {AVATAR_PRESETS.map((url) => (
              <button key={url} type="button" onClick={() => saveAvatar(url)} className={`rounded-xl overflow-hidden border-2 ${avatarUrl === url ? 'border-emerald-400' : 'border-slate-700 hover:border-slate-500'}`} aria-label="Choose profile picture">
                <img src={url} alt="Profile option" className="w-full aspect-square object-cover" />
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={(e) => { e.preventDefault(); if (customAvatarInput.trim()) saveAvatar(customAvatarInput.trim()); }} className="space-y-2">
          <label className="block text-xs font-medium text-slate-300">Custom image URL</label>
          <input value={customAvatarInput} onChange={(e) => setCustomAvatarInput(e.target.value)} placeholder="Paste an image URL" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500" />
          <button type="submit" className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-4 py-2.5 rounded-xl text-xs transition-colors">Use Picture</button>
        </form>

        {saved && <div className="text-xs text-emerald-400 flex items-center gap-1"><Check className="w-3.5 h-3.5" /> Profile picture updated.</div>}
      </section>
    </div>
  );
};
