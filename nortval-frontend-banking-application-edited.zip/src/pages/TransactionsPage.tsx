import React, { useState } from 'react';
import { 
  Search, ArrowUpRight, ArrowDownLeft, Download,
  Receipt, Send
} from 'lucide-react';
import { useBank } from '../context/BankContext';
import { Transaction } from '../types/bank';

interface TransactionsPageProps {
  onSelectTransaction: (tx: Transaction) => void;
  onOpenTransferModal: () => void;
}

export const TransactionsPage: React.FC<TransactionsPageProps> = ({
  onSelectTransaction,
  onOpenTransferModal,
}) => {
  const { transactions, formatAmount } = useBank();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const filteredTransactions = transactions.filter((tx) => {
    const matchesSearch =
      tx.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.referenceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (tx.recipientName && tx.recipientName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (tx.category && tx.category.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesCategory =
      categoryFilter === 'all' ||
      (categoryFilter === 'wires' && (tx.category === 'Wire Transfer' || tx.type === 'transfer_out')) ||
      (categoryFilter === 'deposits' && (tx.category === 'Direct Deposit' || tx.type === 'deposit' || tx.type === 'transfer_in')) ||
      (categoryFilter === 'fees' && tx.category === 'Service Fee');

    return matchesSearch && matchesCategory;
  });

  const handleExportStatement = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-serif">
            Official Ledger & Transaction Records
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit-grade record of all inbound and outbound wire transfers, interest credits, and charges.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportStatement}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3.5 py-2 rounded-xl text-xs font-medium border border-slate-700 transition-colors"
          >
            <Download className="w-4 h-4 text-slate-400" />
            <span>Print Ledger</span>
          </button>
          <button
            onClick={onOpenTransferModal}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-4 py-2 rounded-xl text-xs shadow-lg shadow-emerald-950 transition-colors"
          >
            <Send className="w-4 h-4" />
            <span>New Wire</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Search */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5 pointer-events-none" />
          <input
            type="text"
            placeholder="Search by reference, recipient, note..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'all', label: 'All Records' },
            { id: 'wires', label: 'Wires & Transfers' },
            { id: 'deposits', label: 'Direct Deposits' },
            { id: 'fees', label: 'Service Fees' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                categoryFilter === cat.id
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Transactions List */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
        {filteredTransactions.length === 0 ? (
          <div className="text-center py-12 space-y-2">
            <Receipt className="w-10 h-10 text-slate-600 mx-auto" />
            <h4 className="text-sm font-semibold text-slate-300">No Transactions Found</h4>
            <p className="text-xs text-slate-500">
              Try adjusting your search criteria or filter options.
            </p>
          </div>
        ) : (
          filteredTransactions.map((tx) => {
            const isDebit = tx.amount < 0;
            const absAmount = Math.abs(tx.amount);

            return (
              <div
                key={tx.id}
                onClick={() => onSelectTransaction(tx)}
                className="p-4 rounded-xl bg-slate-950/60 hover:bg-slate-800/80 border border-slate-800/80 hover:border-slate-700 transition-all cursor-pointer flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3.5">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                    isDebit
                      ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                      : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  }`}>
                    {isDebit ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownLeft className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="font-semibold text-xs sm:text-sm text-white group-hover:text-emerald-400 transition-colors">
                      {tx.description}
                    </div>
                    <div className="text-xs text-slate-400 flex flex-wrap items-center gap-2 mt-0.5">
                      <span>{tx.date}</span>
                      <span>•</span>
                      <span className="font-mono text-slate-500 text-[11px]">{tx.referenceNumber}</span>
                      <span>•</span>
                      <span className="text-slate-400">{tx.category}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className={`font-mono font-bold text-sm sm:text-base ${
                    isDebit ? 'text-slate-100' : 'text-emerald-400'
                  }`}>
                    {isDebit ? '-' : '+'}{formatAmount(absAmount)}
                  </div>
                  <div className="flex items-center justify-end gap-1 mt-1">
                    <span className="text-[10px] text-emerald-300 font-medium bg-emerald-500/10 px-2 py-0.2 rounded-full border border-emerald-500/20">
                      Settled
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
