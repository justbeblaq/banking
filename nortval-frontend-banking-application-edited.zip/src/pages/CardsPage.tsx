import React, { useState } from 'react';
import { 
  CreditCard, Lock, Unlock, Eye, EyeOff, ShieldCheck, 
  Sparkles, Phone
} from 'lucide-react';
import { useBank } from '../context/BankContext';
import { BANK_CONFIG } from '../config/bankConfig';

export const CardsPage: React.FC = () => {
  const { cards, toggleCardFreeze, openCustomerService, formatAmount } = useBank();
  const [revealedCardId, setRevealedCardId] = useState<string | null>(null);

  const toggleReveal = (id: string) => {
    setRevealedCardId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-serif">
            Nortval Private Client Debit Cards
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage your high-limit Visa Infinite & Mastercard World Elite debit cards.
          </p>
        </div>

        <button
          onClick={() => openCustomerService('Request Replacement Debit Card', 'I would like to request an additional or replacement metal debit card.')}
          className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3.5 py-2 rounded-xl text-xs font-medium border border-slate-700 transition-colors"
        >
          <CreditCard className="w-4 h-4 text-emerald-400" />
          <span>Request New Metal Card</span>
        </button>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {cards.map((card) => {
          const isRevealed = revealedCardId === card.id;

          return (
            <div
              key={card.id}
              className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5"
            >
              {/* Card Surface */}
              <div
                className={`rounded-2xl p-6 bg-gradient-to-tr ${card.color} border border-slate-700 shadow-2xl relative overflow-hidden text-slate-100 space-y-6 transition-all ${
                  card.isFrozen ? 'opacity-60 grayscale' : ''
                }`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] tracking-widest text-emerald-400 font-semibold uppercase">
                      {card.type}
                    </span>
                    <div className="text-base font-bold font-serif text-white tracking-wide">
                      NORTVAL PRIVATE BANK
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {card.isFrozen && (
                      <span className="text-[10px] bg-red-500/80 text-white font-bold px-2 py-0.5 rounded-full uppercase">
                        Card Frozen
                      </span>
                    )}
                    <div className="w-10 h-7 bg-amber-400/90 rounded-md border border-amber-300/50 flex items-center justify-center text-[8px] font-mono font-bold text-slate-900">
                      CHIP
                    </div>
                  </div>
                </div>

                <div className="text-base sm:text-lg font-mono tracking-widest text-slate-100 font-semibold py-2">
                  {isRevealed
                    ? card.cardNumber.replace(/•••• •••• ••••/g, '4819 9281 7740')
                    : card.cardNumber}
                </div>

                <div className="flex justify-between items-end text-xs">
                  <div>
                    <div className="text-[9px] uppercase tracking-wider text-slate-400">Cardholder</div>
                    <div className="font-semibold text-slate-100">{card.cardHolder}</div>
                  </div>

                  <div className="flex gap-4">
                    <div>
                      <div className="text-[9px] uppercase tracking-wider text-slate-400">Expires</div>
                      <div className="font-mono text-slate-200">{card.expiryDate}</div>
                    </div>
                    <div>
                      <div className="text-[9px] uppercase tracking-wider text-slate-400">CVV</div>
                      <div className="font-mono text-slate-200">
                        {isRevealed ? card.cvv : '•••'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card Controls & Limits */}
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-3 bg-slate-950/70 rounded-xl border border-slate-800">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span className="text-slate-300">Daily Spending Limit:</span>
                  </div>
                  <span className="font-mono font-bold text-white">
                    {formatAmount(card.spendingLimit)}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => toggleReveal(card.id)}
                    className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium py-2.5 px-3 rounded-xl border border-slate-700 transition-colors"
                  >
                    {isRevealed ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    <span>{isRevealed ? 'Hide Details' : 'Reveal Number'}</span>
                  </button>

                  <button
                    onClick={() => toggleCardFreeze(card.id)}
                    className={`flex items-center justify-center gap-2 font-semibold py-2.5 px-3 rounded-xl border transition-colors ${
                      card.isFrozen
                        ? 'bg-emerald-950/60 border-emerald-500/60 text-emerald-300 hover:bg-emerald-900/60'
                        : 'bg-amber-950/60 border-amber-500/60 text-amber-300 hover:bg-amber-900/60'
                    }`}
                  >
                    {card.isFrozen ? (
                      <>
                        <Unlock className="w-4 h-4" />
                        <span>Unfreeze Card</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4" />
                        <span>Lock / Freeze Card</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Security Info Card */}
      <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Zero-Liability Fraud Protection on all domestic & international transactions.</span>
        </div>
        <button
          onClick={() => openCustomerService('Card Inquiries', 'I have questions regarding my debit card limits and international access.')}
          className="text-emerald-400 hover:underline flex items-center gap-1 font-medium"
        >
          <Phone className="w-3.5 h-3.5" />
          <span>SMS Support ({BANK_CONFIG.customerServicePhone})</span>
        </button>
      </div>
    </div>
  );
};
