import React from 'react';
import { 
  Send, Phone, Banknote, ArrowUpRight, ArrowDownLeft, Sparkles, Building2,
  TrendingUp, CreditCard, FileText, ChevronRight
} from 'lucide-react';
import { useBank } from '../context/BankContext';
import { BANK_CONFIG } from '../config/bankConfig';
import { Transaction } from '../types/bank';

interface DashboardPageProps {
  onOpenTransferModal: () => void;
  onSelectTransaction: (tx: Transaction) => void;
  onNavigate: (tab: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  onOpenTransferModal,
  onSelectTransaction,
  onNavigate,
}) => {
  const { 
    user, 
    balance, 
    savingsBalance, 
    formatAmount, 
    transactions, 
    cards, 
    openCustomerService,
    openLoanModal,
    openServiceUnavailableModal,
  } = useBank();

  const totalNetWorth = balance + savingsBalance;
  const recentTransactions = transactions.slice(0, 5);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Welcome & Account Identity Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-2xl backdrop-blur-md">
        <div className="flex items-center gap-4">
          <img
            src={user.avatarUrl}
            alt={user.name}
            className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl object-cover border-2 border-emerald-500/40 shadow-md"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold text-white font-serif">
                Welcome back, {user.name}
              </h1>
              <span className="hidden sm:inline-flex text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                Verified Private Client
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Account No: <span className="font-mono text-slate-200">{BANK_CONFIG.account.accountNumber}</span> • {BANK_CONFIG.account.accountType}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenTransferModal}
            className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-semibold px-4 py-2.5 rounded-xl text-xs shadow-lg shadow-emerald-950 transition-all hover:scale-[1.02]"
          >
            <Send className="w-4 h-4" />
            <span>Send Wire Transfer</span>
          </button>
          <button
            onClick={() => openCustomerService('Priority Concierge Request')}
            className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3.5 py-2.5 rounded-xl text-xs font-medium border border-slate-700 transition-colors"
          >
            <Phone className="w-4 h-4 text-emerald-400" />
            <span>Support</span>
          </button>
        </div>
      </div>

      {/* Main Balances Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Primary Checking / Wire Account */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-850 to-emerald-950/40 border border-emerald-500/30 rounded-2xl p-5 shadow-xl relative overflow-hidden group">
          <div className="flex justify-between items-start mb-3">
            <div>
              <span className="text-[11px] uppercase tracking-wider font-semibold text-emerald-400">
                Primary Checking & Wire Liquidity
              </span>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-white mt-1 tracking-tight">
                {formatAmount(balance)}
              </div>
            </div>
            <div className="p-2.5 bg-emerald-500/10 rounded-xl text-emerald-400 border border-emerald-500/20">
              <Building2 className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-center justify-between text-xs pt-3 border-t border-slate-800/80">
            <span className="text-slate-400 font-mono">Acct: •••• 7740</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" />
              Available for Wire
            </span>
          </div>
        </div>

        {/* High-Yield Savings Reserve */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl relative overflow-hidden">
          <div className="flex justify-between items-start mb-3">
            <div>
              <span className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">
                Treasury Reserve (4.85% APY)
              </span>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-white mt-1 tracking-tight">
                {formatAmount(savingsBalance)}
              </div>
            </div>
            <div className="p-2.5 bg-blue-500/10 rounded-xl text-blue-400 border border-blue-500/20">
              <Banknote className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-center justify-between text-xs pt-3 border-t border-slate-800/80">
            <span className="text-slate-400 font-mono">Acct: •••• 9281</span>
            <span className="text-blue-400 font-medium">Interest Credited Monthly</span>
          </div>
        </div>

        {/* Combined Net Worth */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl relative overflow-hidden">
          <div className="flex justify-between items-start mb-3">
            <div>
              <span className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">
                Total Nortval Net Liquidity
              </span>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-white mt-1 tracking-tight">
                {formatAmount(totalNetWorth)}
              </div>
            </div>
            <div className="p-2.5 bg-amber-500/10 rounded-xl text-amber-400 border border-amber-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-center justify-between text-xs pt-3 border-t border-slate-800/80">
            <span className="text-slate-400">Combined Assets</span>
            <span className="text-slate-200 font-medium">Combined Assets</span>
          </div>
        </div>
      </div>

      {/* Quick Banking Actions Grid */}
      <div className="space-y-3">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Private Client Operations & Services
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <button
            onClick={onOpenTransferModal}
            className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-emerald-500/40 rounded-2xl flex flex-col items-center text-center gap-2 group transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 group-hover:bg-emerald-500/20 text-emerald-400 flex items-center justify-center transition-colors">
              <Send className="w-5 h-5" />
            </div>
            <span className="text-xs font-semibold text-slate-200 group-hover:text-white">
              Wire Transfer
            </span>
            <span className="text-[10px] text-slate-500">Real-Time Settle</span>
          </button>

          <button
            onClick={openLoanModal}
            className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-amber-500/40 rounded-2xl flex flex-col items-center text-center gap-2 group transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 group-hover:bg-amber-500/20 text-amber-400 flex items-center justify-center transition-colors">
              <Banknote className="w-5 h-5" />
            </div>
            <span className="text-xs font-semibold text-slate-200 group-hover:text-white">
              Apply for Loan
            </span>
            <span className="text-[10px] text-slate-500">Notice & SMS Desk</span>
          </button>


          <button
            onClick={() => openServiceUnavailableModal(
              'Mobile Check Deposit',
              'Check Inward Clearing',
              'Check deposit services require manual image verification by your Nortval concierge. Please contact customer service at ' + BANK_CONFIG.customerServicePhone + ' for secure digital intake.'
            )}
            className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-2xl flex flex-col items-center text-center gap-2 group transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 group-hover:bg-blue-500/20 text-blue-400 flex items-center justify-center transition-colors">
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-xs font-semibold text-slate-200 group-hover:text-white">
              Deposit Check
            </span>
            <span className="text-[10px] text-slate-500">Inward Clearing</span>
          </button>

          <button
            onClick={() => openServiceUnavailableModal(
              'Bill Pay & Escrow',
              'Commercial Bill Pay',
              'Bill pay and tax escrow disbursements are handled directly by your private banker. Reach out to SMS customer service for automatic scheduling.'
            )}
            className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-2xl flex flex-col items-center text-center gap-2 group transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 group-hover:bg-purple-500/20 text-purple-400 flex items-center justify-center transition-colors">
              <CreditCard className="w-5 h-5" />
            </div>
            <span className="text-xs font-semibold text-slate-200 group-hover:text-white">
              Pay Bills
            </span>
            <span className="text-[10px] text-slate-500">Concierge Route</span>
          </button>

        </div>
      </div>

      {/* Main Split: Recent Activity & Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Recent Transactions */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white font-serif">
                Recent Wire & Account Activity
              </h3>
              <p className="text-xs text-slate-400">
                Real-time ledger updates & transaction receipts
              </p>
            </div>
            <button
              onClick={() => onNavigate('transactions')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1 hover:underline"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {recentTransactions.map((tx) => {
              const isDebit = tx.amount < 0;
              const absVal = Math.abs(tx.amount);

              return (
                <div
                  key={tx.id}
                  onClick={() => onSelectTransaction(tx)}
                  className="p-3.5 rounded-xl bg-slate-950/60 hover:bg-slate-800/80 border border-slate-800/80 hover:border-slate-700 transition-all cursor-pointer flex items-center justify-between gap-3 group"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isDebit
                        ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    }`}>
                      {isDebit ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownLeft className="w-5 h-5" />}
                    </div>
                    <div>
                      <div className="font-semibold text-xs text-white group-hover:text-emerald-400 transition-colors">
                        {tx.description}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                        <span>{tx.date}</span>
                        <span>•</span>
                        <span className="font-mono text-slate-500">{tx.referenceNumber}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className={`font-mono font-bold text-xs sm:text-sm ${
                      isDebit ? 'text-slate-100' : 'text-emerald-400'
                    }`}>
                      {isDebit ? '-' : '+'}{formatAmount(absVal)}
                    </div>
                    <span className="inline-block text-[10px] text-emerald-300 font-medium bg-emerald-500/10 px-2 py-0.2 rounded-full border border-emerald-500/20 mt-0.5">
                      Completed
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col: Virtual Debit Card */}
        <div className="space-y-6">
          {/* Virtual Card Preview */}
          {cards[0] && (
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-semibold tracking-wider text-slate-400">
                  Nortval Private Debit Card
                </span>
                <button
                  onClick={() => onNavigate('cards')}
                  className="text-xs text-emerald-400 hover:underline"
                >
                  Manage
                </button>
              </div>

              {/* Physical/Digital Card Style */}
              <div className="rounded-2xl p-5 bg-gradient-to-tr from-slate-950 via-slate-900 to-emerald-950/80 border border-slate-700/80 shadow-2xl relative overflow-hidden text-slate-100 space-y-4">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] tracking-widest text-emerald-400 font-semibold uppercase">
                      {cards[0].type}
                    </span>
                    <div className="text-sm font-bold font-serif text-white">NORTVAL BANK</div>
                  </div>
                  <div className="w-8 h-6 bg-amber-400/80 rounded-md border border-amber-300/40"></div>
                </div>

                <div className="text-sm sm:text-base font-mono tracking-widest text-slate-100 font-semibold pt-1">
                  {cards[0].cardNumber}
                </div>

                <div className="flex justify-between items-end text-xs">
                  <div>
                    <div className="text-[9px] uppercase text-slate-400">Cardholder</div>
                    <div className="font-semibold text-slate-200">{cards[0].cardHolder}</div>
                  </div>
                  <div>
                    <div className="text-[9px] uppercase text-slate-400">Expires</div>
                    <div className="font-mono text-slate-200">{cards[0].expiryDate}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
